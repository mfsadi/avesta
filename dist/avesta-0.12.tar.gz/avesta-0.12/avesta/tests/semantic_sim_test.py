# TBD
from avesta.tools.similarity.semantic_sim import semantic_synonym_checker

status = semantic_synonym_checker ("پیراهن مردانه مشکی", "پیراهن سیاه مردانه")