from PersianStemmer import PersianStemmer
ps = PersianStemmer()
