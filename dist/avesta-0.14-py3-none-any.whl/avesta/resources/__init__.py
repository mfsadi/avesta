from avesta.resources.corpora import * 
from avesta.resources.synonym import *
