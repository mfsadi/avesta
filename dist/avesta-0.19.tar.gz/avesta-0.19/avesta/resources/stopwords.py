PERSIAN_STOPWORDS = ['از', 'با', 'و', 'برای']

