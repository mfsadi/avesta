from avesta.tools import similarity
