from avesta.tools.similarity.lexical_sim import lexical_synonym_checker
res = lexical_synonym_checker("پیراهن مردانه سایز 12 قرمز","پیراهن قرمز       مردانه سایز ۱۲")
print(res)